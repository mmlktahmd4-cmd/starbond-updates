#!/bin/sh
# مثبّت نظام Starbond كواجهة/نظام إدارة أساسي على KT OpenWrt الحالي.
set -e
IPKG_INSTROOT="${IPKG_INSTROOT:-}"
cd "$(dirname "$0")"

if [ ! -f /etc/openwrt_release ]; then
	echo "شغّل هذا على الراوتر فقط."
	exit 1
fi

command -v nft >/dev/null 2>&1 || {
	echo "nft غير موجود."
	exit 1
}

VER="1.9.0"
STAMP=$(date +%Y%m%d-%H%M%S)

mkdir -p /usr/sbin /etc/hotplug.d/iface /etc/sysctl.d /etc/config /etc/init.d \
	/etc/starbond /var/run/starbond /www/starbond /www/cgi-bin \
	/usr/lib/lua/luci/controller /etc/uci-defaults /root/starbond-os-backup-$STAMP

[ -f /www/index.html ] && cp -a /www/index.html /root/starbond-os-backup-$STAMP/index.html || true
[ -d /www/starbond ] && cp -a /www/starbond /root/starbond-os-backup-$STAMP/starbond || true

cp -f files/usr/sbin/starbond-apply /usr/sbin/starbond-apply
cp -f files/usr/sbin/starbond-status /usr/sbin/starbond-status
cp -f files/usr/sbin/starbond-rollback /usr/sbin/starbond-rollback
cp -f files/usr/sbin/starbond-engine /usr/sbin/starbond-engine
cp -f files/usr/sbin/starbond-track /usr/sbin/starbond-track
cp -f files/usr/sbin/starbond-speedtest /usr/sbin/starbond-speedtest
cp -f files/usr/sbin/starbond-luci /usr/sbin/starbond-luci
cp -f files/usr/sbin/starbond-live /usr/sbin/starbond-live
cp -f files/usr/sbin/starbond-lb /usr/sbin/starbond-lb
cp -f files/usr/sbin/starbond-update /usr/sbin/starbond-update
cp -f files/usr/sbin/starbond-apps /usr/sbin/starbond-apps
cp -f files/usr/sbin/starbond-license /usr/sbin/starbond-license
mkdir -p /usr/share/starbond/apps
rm -f /usr/share/starbond/apps/*.app
cp -f files/usr/share/starbond/apps/*.app /usr/share/starbond/apps/
cp -f files/etc/hotplug.d/iface/99-starbond /etc/hotplug.d/iface/99-starbond
cp -f files/etc/sysctl.d/99-starbond.conf /etc/sysctl.d/99-starbond.conf
cp -f files/etc/init.d/starbond /etc/init.d/starbond
chmod 755 /usr/sbin/starbond-apply /usr/sbin/starbond-status /usr/sbin/starbond-rollback \
	/usr/sbin/starbond-engine /usr/sbin/starbond-track /usr/sbin/starbond-speedtest /usr/sbin/starbond-luci /usr/sbin/starbond-live /usr/sbin/starbond-lb /usr/sbin/starbond-update /usr/sbin/starbond-apps /usr/sbin/starbond-license /etc/init.d/starbond

cp -f files/www/starbond/index.html /www/starbond/index.html
cp -f files/www/starbond/styles.css /www/starbond/styles.css
cp -f files/www/starbond/app.js /www/starbond/app.js
cp -f files/www/cgi-bin/starbond /www/cgi-bin/starbond
chmod 755 /www/cgi-bin/starbond

if [ -f /www/index.html ] && [ ! -f /www/index.html.starbond-bak ]; then
	cp -a /www/index.html /www/index.html.starbond-bak
fi
cp -f files/www/index.html /www/index.html
cp -f files/usr/lib/lua/luci/controller/starbond.lua /usr/lib/lua/luci/controller/starbond.lua
[ -f files/etc/banner ] && cp -f files/etc/banner /etc/banner || true

if [ -f files/etc/uci-defaults/99-starbond-os ]; then
	cp -f files/etc/uci-defaults/99-starbond-os /etc/uci-defaults/99-starbond-os
	chmod 755 /etc/uci-defaults/99-starbond-os
	sh /etc/uci-defaults/99-starbond-os || true
	rm -f /etc/uci-defaults/99-starbond-os
fi

echo "$VER" > /etc/starbond/os-version
echo "$STAMP" > /etc/starbond/os-installed
echo "/root/starbond-os-backup-$STAMP" > /etc/starbond/os-lastbackup

# أول تركيب: إعداد حسب منافذ الجهاز الفعلية
if [ ! -f /etc/config/starbond ]; then
	if [ -e /sys/class/net/lan1 ] && [ -e /sys/class/net/wan ] && [ -f files/etc/config/starbond ]; then
		cp -f files/etc/config/starbond /etc/config/starbond      # KT708: الإعداد الأصلي
	else
		# جهاز آخر (مثل RB5009: p1..p8/sfp): بدون خطوط، الخروج على آخر منفذ، والباقي إدارة لحتى تضيف الخطوط من اللوحة
		last=""
		for d in /sys/class/net/*; do
			n=${d##*/}
			case "$n" in lo|br-*|pppoe-*|phy*|wlan*|*.*) continue ;; esac
			[ -d "$d/bridge" ] && continue; [ -d "$d/dsa" ] && continue
			[ -e "$d/phys_port_name" ] || [ -e "$d/device" ] || continue
			case "$n" in sfp*) continue ;; esac
			last=$n
		done
		[ -e /sys/class/net/p8 ] && last=p8
		cat > /etc/config/starbond <<CFG
config starbond 'main'
	option policy 'balanced'
	option pin 'smart'
	option exit_port '${last:-p8}'
	option exit_mode 'dhcp'
	option lan_ip '10.10.10.1'
	option lan_mask '255.255.255.0'
	option mikrotik_ip '10.10.10.2'
	option offload 'soft'
	list track_ip '1.1.1.1'
	list track_ip '8.8.8.8'
	list track_ip '9.9.9.9'
CFG
	fi
fi

# التحديث التلقائي: اسم المستودع (من أداة الإصدار) + الجدولة اليومية
rm -f /etc/starbond/update.pub
[ -s files/etc/starbond/update.repo ] && cp -f files/etc/starbond/update.repo /etc/starbond/update.repo
/usr/sbin/starbond-update init >/dev/null 2>&1 || true
/usr/sbin/starbond-license init >/dev/null 2>&1 || true

# أداة conntrack: لما خط يسقط منمسح جلساته فوراً (ألعاب/مكالمات بتنقل لخط حي بثواني بدل ما تعلق)
if ! command -v conntrack >/dev/null 2>&1; then
	free=$(df -k /overlay 2>/dev/null | awk 'NR==2 {print $4}')
	if [ "${free:-0}" -gt 2048 ]; then
		( if command -v apk >/dev/null 2>&1; then apk update >/dev/null 2>&1; apk add conntrack >/dev/null 2>&1
		  elif command -v opkg >/dev/null 2>&1; then opkg update >/dev/null 2>&1 && opkg install conntrack >/dev/null 2>&1; fi
		  logger -t starbond "conntrack: $(command -v conntrack || echo 'ما انركّب')" ) </dev/null >/dev/null 2>&1 &
	fi
fi

# crond بيسجّل كل مهمة كـ "cron.err" (ضجيج بالسجل): خليه يسجّل الأخطاء الحقيقية بس
if [ "$(uci -q get system.@system[0].cronloglevel)" != 9 ]; then
	uci -q set system.@system[0].cronloglevel=9 && uci -q commit system && /etc/init.d/cron restart >/dev/null 2>&1
fi

sysctl -p /etc/sysctl.d/99-starbond.conf >/dev/null 2>&1 || true

if [ -f /etc/config/starbond ]; then
	/etc/init.d/starbond enable 2>/dev/null || true
	if uci -q get starbond.@wan[0] >/dev/null 2>&1; then
		/etc/init.d/starbond restart 2>/dev/null || true
	fi
fi

# واجهة واحدة: Starbond (LuCI تتحوّل للوحتنا؛ للرجوع: starbond-luci on)
for p in $(pgrep -f "starbond-live" 2>/dev/null); do kill "$p" 2>/dev/null; done
rm -rf /var/run/starbond-live.lock
( sleep 2; /usr/sbin/starbond-luci off ) >/dev/null 2>&1 &

echo "STARBOND_OS_OK version=$VER"
echo "الواجهة الوحيدة: http://192.168.1.1/starbond/"
echo "الواجهة: http://192.168.1.1/starbond/"
