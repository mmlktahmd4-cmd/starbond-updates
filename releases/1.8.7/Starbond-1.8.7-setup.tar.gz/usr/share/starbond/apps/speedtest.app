name=فحص السرعة
desc=Speedtest (Ookla) و fast.com و nPerf. اسم المزوّد اللي بيطلع بالفحص هو اسم الخط اللي بتختاره.
order=4
match=addr
cidr=
domains=speedtest.net www.speedtest.net c.speedtest.net secure.speedtest.net api.speedtest.net b.cdnst.net ookla.com www.ookla.com secure.ookla.com fast.com www.fast.com api.fast.com nperf.com www.nperf.com speedof.me openspeedtest.com
tcp=8080,5060
udp=
