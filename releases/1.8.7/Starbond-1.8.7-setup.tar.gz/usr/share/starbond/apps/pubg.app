name=ببجي موبايل
desc=اللعب حسب منافذ اللعبة المعروفة + سيرفرات الدخول. البينغ بيضل ثابت لأن الجلسة كلها على خط واحد.
order=2
match=all
cidr=
domains=pubgmobile.com www.pubgmobile.com igamecj.com cdn.igamecj.com ig-us-sdkapi.igamecj.com gcloudcs.com anticheatexpert.com proximabeta.net tencentgames.com
tcp=8011,10012,13004,14000,17000,17500,18081,20000-20002
udp=7086-7995,8011,10010-10013,10039,10096,10491,10612,11000-14000,15692,17000,17500,20000-20002,41182-41192
