name=واتساب
desc=رسائل ومكالمات واتساب. سيرفرات واتساب مشتركة مع فيسبوك وانستغرام، فبيمشوا معه على نفس الخط.
order=1
match=all
cidr=31.13.24.0/21 31.13.64.0/18 45.64.40.0/22 57.144.0.0/14 66.220.144.0/20 69.63.176.0/20 69.171.224.0/19 74.119.76.0/22 102.132.96.0/20 102.221.188.0/22 103.4.96.0/22 129.134.0.0/16 147.75.208.0/20 157.240.0.0/16 163.70.128.0/17 173.252.64.0/18 179.60.192.0/22 185.60.216.0/22 185.89.216.0/22 204.15.20.0/22
domains=whatsapp.net g.whatsapp.net c.whatsapp.net e1.whatsapp.net e2.whatsapp.net e3.whatsapp.net e4.whatsapp.net e5.whatsapp.net e6.whatsapp.net e7.whatsapp.net e8.whatsapp.net e9.whatsapp.net e10.whatsapp.net e11.whatsapp.net e12.whatsapp.net e13.whatsapp.net e14.whatsapp.net e15.whatsapp.net e16.whatsapp.net mmg.whatsapp.net media.fmed1-1.fna.whatsapp.net static.whatsapp.net pps.whatsapp.net v.whatsapp.net web.whatsapp.com whatsapp.com www.whatsapp.com wa.me
tcp=5222,5223,4244,5242
udp=3478
