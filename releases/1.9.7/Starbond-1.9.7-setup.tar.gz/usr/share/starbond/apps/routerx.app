name=RouterX
desc=سيرفر RouterX: نفق WireGuard ولوحة الإدارة وتطبيقات الجوال. لازم يضل على خط واحد ثابت، وإلا النفق بيفصل كل ما الاتصال يتنقل بين الخطوط والسيرفر بيشوف الشبكة من عنوانين.
order=5
match=addr
cidr=191.218.161.141/32
domains=routrx.com www.routrx.com
tcp=
udp=
