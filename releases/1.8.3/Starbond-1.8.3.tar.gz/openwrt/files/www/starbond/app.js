/* Starbond — واجهة التشغيل v2 */
(() => {
  "use strict";
  const API = "/cgi-bin/starbond";
  const UI_VER = "1.8.3";          // لازم يطابق نسخة النظام؛ إذا المتصفح شايل نسخة قديمة منعيد التحميل
  const POLL_MS = 5000;            // الحالة الكاملة (إعدادات، عناوين، أحداث)
  const LIVE_MS = 1000;            // احتياط (CGI) إذا البث اللحظي مش متوفر
  const RT_MS = 250;               // البث اللحظي: 4 قراءات بالثانية من ملف بالـ RAM
  const WIN = 1.5;                 // القياس الخام = متوسط آخر ثانية ونص من عدّادات الراوتر
  const TAU = 0.8;                 // تنعيم أسّي فوق القياس (ثواني): ثابت بس بيلحق التغيير بسرعة
  const DIAL = [0, 5, 10, 25, 50, 100, 250, 500, 1000];   // تدريج ثابت متل عدّادات الفحص الاحترافية
  const HIST = 240;                // نقطة كل نص ثانية × 240 = دقيقتين
  const PORTS_ALL = ["wan", "lan1", "lan2", "lan3", "lan4", "lan5"];
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

  const S = {
    st: null,            // آخر status
    last: null,          // عينة العدّادات السابقة
    rates: {},           // iface -> {rx, tx} Mb/s
    exitRate: { rx: 0, tx: 0 },
    cpu: null,
    hist: [],            // [{d,u}]
    lhist: {},           // iface -> [{d,u}]
    view: "dash",
    authed: false,
    loaded: false,
    saving: false,
    editIdx: null,
    lineKey: "",
    cardKey: "",
    speedTimer: null,
    netTimer: null,
    formDirty: {},
  };

  /* ---------------- أدوات ---------------- */
  function toast(msg) {
    const el = $("#toast");
    el.textContent = msg; el.hidden = false;
    clearTimeout(toast._t); toast._t = setTimeout(() => { el.hidden = true; }, 5000);
  }
  function fmt(v) {
    v = Number(v) || 0;
    if (v >= 1000) return (v / 1000).toFixed(2) + " Gb/s";
    return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2));
  }
  function fmtU(v) { v = Number(v) || 0; return v >= 1000 ? (v / 1000).toFixed(2) + " Gb/s" : fmt(v) + " Mb/s"; }
  function fmtBytes(n) {
    n = Number(n) || 0;
    const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (n >= 100 || i === 0 ? n.toFixed(0) : n.toFixed(1)) + " " + u[i];
  }
  function fmtDur(s) {
    s = Math.max(0, Math.floor(Number(s) || 0));
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    if (d) return `${d}ي ${h}س`;
    if (h) return `${h}س ${m}د`;
    if (m) return `${m}د ${s % 60}ث`;
    return `${s}ث`;
  }
  function niceMax(v, floor) {
    const steps = [1, 2, 5, 10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000, 2500, 5000, 10000];
    const want = Math.max(v * 1.2, floor);
    for (const s of steps) if (s >= want) return s;
    return Math.ceil(want / 1000) * 1000;
  }
  const modeLabel = (m) => ({ dhcp: "تلقائي", static: "ثابت", pppoe: "برودباند" })[m] || m;
  const stateLabel = (w) => (!w.enabled ? "موقوف" : w.state === "online" ? "متصل" : "ساقط");
  const stateCls = (w) => (!w.enabled ? "dis" : w.state === "online" ? "on" : "off");

  async function api(action, body, opts) {
    opts = opts || {};
    const init = body
      ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
      : { method: "GET" };
    init.credentials = "same-origin";
    const url = `${API}?action=${action}` + (body ? "" : `&_=${Date.now()}`);
    const r = await fetch(url, init);
    const text = await r.text();
    if (opts.text) {
      if (r.status === 401) { showAuth("login"); throw new Error("سجّل الدخول"); }
      return text;
    }
    let data;
    try { data = JSON.parse(text); } catch (_) { throw new Error(text.slice(0, 200) || "استجابة غير صالحة"); }
    if (r.status === 401 && data.auth) { showAuth(data.auth); throw new Error(data.error || "سجّل الدخول"); }
    if (!r.ok || data.ok === false) {
      const er = new Error(data.error || "فشل الطلب"); er.fromRouter = true; throw er;
    }
    return data;
  }

  /* ---------------- العيّنات والسرعات ----------------
     العدّادات بتيجي من live (لقطة وحدة لكل الأجهزة + وقت دقيق) كل ثانية.
     سرعة الخط من منفذه الفعلي (lan1...) مش من pppoe-wanX: مع التسريع حزم البرودباند
     ما بتمر على pppoe-wanX فعدّاده بيبيّن الخط واقف وهو شغّال. */
  const devOf = (w, dev) => (dev[w.device] ? w.device : w.cdev && dev[w.cdev] ? w.cdev : w.l3);
  function exitPorts(st) {
    if (S.noLive) return ["__exit"];
    const e = (st && st.exit) || {};
    return e.ports && e.ports.length ? e.ports : (e.dev ? [e.dev] : []);
  }
  function liveFromStatus(st) {      // راوتر قديم بدون live: نفس الحساب من status
    const dev = {};
    (st.wans || []).forEach((w) => { dev[w.cdev || w.l3 || w.device] = [Number(w.rx_bytes) || 0, Number(w.tx_bytes) || 0]; });
    if (st.exit) dev.__exit = [Number(st.exit.rx_bytes) || 0, Number(st.exit.tx_bytes) || 0];
    return { ts: st.ts, cpu_raw: st.cpu_raw, dev };
  }
  function sample(lv) {
    const st = S.st;
    const cur = { ts: Number(lv.ts) || 0, dev: lv.dev || {}, cpu: lv.cpu_raw || null };
    const buf = S.buf || (S.buf = []);
    let last = buf[buf.length - 1];
    if (last && (cur.ts < last.ts - 5 || cur.ts - last.ts > 30)) { buf.length = 0; last = null; S.lastPush = 0; }  // ريستارت أو غياب طويل
    if (last && cur.ts <= last.ts) return;                     // نفس اللقطة
    buf.push(cur);
    while (buf.length > 2 && cur.ts - buf[1].ts >= WIN) buf.shift();
    // المرجع: أقدم لقطة ضمن آخر ثانية تقريباً
    const p = buf.length > 1 ? buf[0] : null;
    S.liveDev = cur.dev; S.liveTs = cur.ts;
    if (p && st && cur.ts - p.ts >= 0.2) {
      const dt = cur.ts - p.ts;
      const rate = (a, b) => Math.max(0, a - b) * 8 / dt / 1e6;
      const prevTs = S.smTs || 0; S.smTs = cur.ts;
      const al = prevTs && cur.ts > prevTs ? 1 - Math.exp(-(cur.ts - prevTs) / TAU) : 1;
      const ema = (old, raw) => { const v = old == null ? raw : old + (raw - old) * al; return raw === 0 && v < 0.05 ? 0 : v; };
      const old = S.rates || {};
      S.rates = {};
      let d = 0, u = 0;
      const push = !S.lastPush || cur.ts - S.lastPush >= 0.5;   // نقطة رسم كل نص ثانية
      if (push) S.lastPush = cur.ts;
      (st.wans || []).forEach((w) => {
        const k = devOf(w, cur.dev), c = cur.dev[k], o = p.dev[k];
        const raw = c && o ? { rx: rate(c[0], o[0]), tx: rate(c[1], o[1]) } : { rx: 0, tx: 0 };
        const pr = old[w.iface];
        const r = { rx: ema(pr && pr.rx, raw.rx), tx: ema(pr && pr.tx, raw.tx) };
        S.rates[w.iface] = r; d += r.rx; u += r.tx;
        if (push) { const h = S.lhist[w.iface] || (S.lhist[w.iface] = []); h.push({ d: r.rx, u: r.tx }); if (h.length > HIST) h.shift(); }
      });
      if (push) { S.hist.push({ d, u }); if (S.hist.length > HIST) S.hist.shift(); }
      // الخروج: مجموع منافذه الفعلية (المنفذ + الواي فاي)؛ tx عليها = نازل للزبائن
      let er = 0, et = 0;
      exitPorts(st).forEach((n) => { const c = cur.dev[n], o = p.dev[n]; if (c && o) { er += rate(c[1], o[1]); et += rate(c[0], o[0]); } });
      const pe = S.exitRate || {};
      S.exitRate = { rx: ema(pe.rx, er), tx: ema(pe.tx, et) };
      if (push) { const eh = S.ehist || (S.ehist = []); eh.push({ d: S.exitRate.rx, u: S.exitRate.tx }); if (eh.length > HIST) eh.shift(); }
      if (cur.cpu && p.cpu) {
        const db = cur.cpu[0] - p.cpu[0], dtt = cur.cpu[1] - p.cpu[1];
        if (dtt > 0) {
          const ac = prevTs && cur.ts > prevTs ? 1 - Math.exp(-(cur.ts - prevTs) / 3) : 1;   // المعالج: تنعيم ~3 ثواني
          const raw = Math.min(100, Math.max(0, db * 100 / dtt));
          S.cpu = S.cpu == null ? raw : S.cpu + (raw - S.cpu) * ac;
        }
      }
    }
  }
  const lineBytes = (w) => {             // المجموع من المنفذ الفعلي إذا متوفر
    const dv = S.liveDev, k = dv ? devOf(w, dv) : null;
    return k && dv[k] ? { rx: dv[k][0], tx: dv[k][1] } : { rx: w.rx_bytes, tx: w.tx_bytes };
  };
  const lineRate = (iface) => S.rates[iface] || { rx: 0, tx: 0 };
  function totals() {
    let d = 0, u = 0;
    ((S.st && S.st.wans) || []).forEach((w) => { const r = lineRate(w.iface); d += r.rx; u += r.tx; });
    return { d, u };
  }

  /* ---------------- الرسم ---------------- */
  function dialPct(v) {
    v = Math.max(0, Number(v) || 0);
    const n = DIAL.length - 1;
    for (let i = 0; i < n; i++) if (v < DIAL[i + 1]) return (i + (v - DIAL[i]) / (DIAL[i + 1] - DIAL[i])) / n;
    return 1;
  }
  function gaugeSVG() {
    // نصف دائرة: مركز (60,60) نصف قطر 48، وعلامات التدريج جوّا القوس
    const n = DIAL.length - 1;
    const ticks = DIAL.map((v, i) => {
      const a = Math.PI * (1 - i / n), x = 60 + 37 * Math.cos(a), y = 62 - 37 * Math.sin(a);
      return `<text class="tick" x="${x.toFixed(1)}" y="${y.toFixed(1)}" text-anchor="middle">${v >= 1000 ? "1G" : v}</text>`;
    }).join("");
    return `<svg viewBox="0 0 120 72" aria-hidden="true">
      <path class="trk" d="M12 60 A48 48 0 0 1 108 60"/>
      <path class="val" d="M12 60 A48 48 0 0 1 108 60" stroke-dasharray="0 400"/>
      ${ticks}
      <line class="needle" x1="60" y1="60" x2="60" y2="18" style="transform: rotate(-90deg)"/>
      <circle class="hub" cx="60" cy="60" r="3.6"/>
    </svg>`;
  }
  const GA = new Map();      // عنصر العدّاد -> {cur, target}
  let gRaf = 0, gLast = 0;
  const fmtG = (v) => (v >= 10 ? v.toFixed(0) : v.toFixed(1));
  function drawGauge(el, v) {
    const pct = dialPct(v), len = Math.PI * 48;
    el.querySelector(".val").setAttribute("stroke-dasharray", `${(len * pct).toFixed(1)} 400`);
    el.querySelector(".needle").style.transform = `rotate(${(-90 + 180 * pct).toFixed(2)}deg)`;
    el.querySelector(".gval b").textContent = fmtG(v);
  }
  function gStep(t) {
    const dt = Math.min(0.1, Math.max(0.001, (t - gLast) / 1000)); gLast = t;
    const k = 1 - Math.exp(-dt / 0.22);
    let moving = false;
    for (const [el, g] of GA) {
      if (!el.isConnected) { GA.delete(el); continue; }
      g.cur += (g.target - g.cur) * k;
      if (Math.abs(g.target - g.cur) > Math.max(0.02, g.target * 0.002)) moving = true; else g.cur = g.target;
      drawGauge(el, g.cur);
    }
    gRaf = moving ? requestAnimationFrame(gStep) : 0;
  }
  function setGauge(el, value) {
    if (!el) return;
    let g = GA.get(el);
    if (!g) { g = { cur: 0, target: 0 }; GA.set(el, g); }
    g.target = Math.max(0, Number(value) || 0);
    if (document.hidden) { g.cur = g.target; drawGauge(el, g.cur); return; }
    if (!gRaf) { gLast = performance.now(); gRaf = requestAnimationFrame(gStep); }
  }
  function drawLines(canvas, series, opts) {
    // series: [{data:[...], color}]
    opts = opts || {};
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    let max = 0;
    series.forEach((s) => s.data.forEach((v) => { if (v > max) max = v; }));
    max = niceMax(max, opts.floor || 1);
    const padL = opts.axis ? 44 : 2, padR = 6, padT = 8, padB = opts.axis ? 20 : 3;
    const cw = w - padL - padR, ch = h - padT - padB;
    if (opts.axis) {
      ctx.strokeStyle = "rgba(141,151,179,.16)"; ctx.fillStyle = "#8d97b3";
      ctx.font = "11px Segoe UI, Tahoma, sans-serif"; ctx.textAlign = "right"; ctx.textBaseline = "middle";
      for (let i = 0; i <= 4; i++) {
        const y = padT + ch - (ch * i) / 4;
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
        ctx.fillText(fmt((max * i) / 4), padL - 6, y);
      }
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      ctx.fillText("قبل دقيقتين", padL + 2, h - 4);
      ctx.textAlign = "right"; ctx.fillText("الآن", w - padR, h - 4);
    }
    series.forEach((s) => {
      const n = s.data.length; if (n < 2) return;
      const x = (i) => padL + (cw * (HIST - n + i)) / (HIST - 1);
      const y = (v) => padT + ch - (ch * Math.min(v, max)) / max;
      ctx.beginPath();
      s.data.forEach((v, i) => (i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v))));
      ctx.lineWidth = opts.axis ? 2 : 1.6; ctx.strokeStyle = s.color; ctx.lineJoin = "round"; ctx.stroke();
      if (s.fill) {
        ctx.lineTo(x(n - 1), padT + ch); ctx.lineTo(x(0), padT + ch); ctx.closePath();
        const g = ctx.createLinearGradient(0, padT, 0, padT + ch);
        g.addColorStop(0, s.fill); g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g; ctx.fill();
      }
    });
  }

  /* ---------------- الأجزاء ---------------- */
  function renderTopRates() {
    const t = totals();
    $("#hDown").textContent = fmtU(t.d);
    $("#hUp").textContent = fmtU(t.u);
    const nowMs = Date.now();
    if (!S.cpuShownAt || nowMs - S.cpuShownAt >= 1000) {          // رقم المعالج يتغيّر مرة بالثانية
      S.cpuShownAt = nowMs;
      $("#hCpu").textContent = S.cpu == null ? "—" : Math.round(S.cpu) + "%";
    }
    $("#seDown").textContent = fmt(S.exitRate.rx);
    $("#seUp").textContent = fmt(S.exitRate.tx);
  }
  function renderTop() {
    const st = S.st; if (!st) return;
    const wans = st.wans || [];
    const on = wans.filter((w) => w.enabled && w.state === "online").length;
    $("#hVer").textContent = "v" + (st.version || "?");
    $("#hLines").textContent = `${on}/${wans.length}`;
    renderTopRates();
    $("#hMem").textContent = `${st.ram_used_mb}/${st.ram_total_mb}MB`;
    $("#hUptime").textContent = fmtDur(st.uptime_s);
    $("#hTime").textContent = st.now || "—";
    $("#authBanner").hidden = !st.auth_off;
    // بطاقة الخروج
    const c = st.cfg || {};
    $("#sePort").textContent = c.exit_port || "—";
    $("#seDot").className = "dot" + (st.exit && st.exit.up ? " on" : "");
    $("#seMeta").textContent = `${c.exit_mode === "dhcp" ? "DHCP" : "Static"} · ${(c.exit_addr || c.lan_ip || "").split("/")[0]}`;
  }

  function renderKpis() {
    const st = S.st; if (!st) return;
    const wans = st.wans || [], c = st.cfg || {};
    const on = wans.filter((w) => w.enabled && w.state === "online").length;
    const t = totals();
    const exitUp = st.exit && st.exit.up;
    $("#kpis").innerHTML = `
      <div class="kpi down"><small>تحميل الآن</small><b>${fmt(t.d)}<em>Mb/s</em></b><div class="sub">مجموع كل الخطوط</div></div>
      <div class="kpi up"><small>رفع الآن</small><b>${fmt(t.u)}<em>Mb/s</em></b><div class="sub">مجموع كل الخطوط</div></div>
      <div class="kpi ${on ? "ok" : "bad"}"><small>الخطوط المتصلة</small><b>${on}<em>/ ${wans.length}</em></b><div class="sub">${on > 1 ? "الدمج شغّال" : on === 1 ? "خط واحد بس" : "ما في خط متصل"}</div></div>
      <div class="kpi ${exitUp ? "ok" : "bad"}"><small>خروج الميكروتك</small><b>${esc(c.exit_port || "—")}</b><div class="sub">${exitUp ? "موصول" : "مفصول"} · ${c.exit_mode === "dhcp" ? "DHCP" : "ثابت"} ${esc((c.exit_addr || "").split("/")[0])}</div></div>
      <div class="kpi"><small>سياسة الدمج</small><b style="font-size:1.15rem">${c.policy === "failover" ? "احتياط" : "متساوٍ"}</b><div class="sub">${c.pin === "ip" ? "لكل جهاز" : c.pin === "smart" ? "ذكي" : "لكل اتصال"} · تسريع: ${esc(c.offload === "off" ? "متوقف" : c.offload === "hard" ? "قطع" : "برمجي")}</div></div>`;
  }

  function renderCards() {
    const wans = (S.st && S.st.wans) || [];
    const box = $("#lineCards");
    const c0 = (S.st && S.st.cfg) || {}, ex0 = (S.st && S.st.exit) || {};
    const key = wans.map((w) => [w.iface, w.name, w.device, w.mode, w.enabled, w.state].join("~")).join("|") + "|x~" + [c0.exit_port, c0.exit_mode, ex0.up].join("~");
    if (key !== S.cardKey) {
      S.cardKey = key;
      box.innerHTML = wans.length ? wans.map((w) => `
        <article class="lcard ${w.enabled && w.state === "online" ? "" : "off"}" data-if="${esc(w.iface)}">
          <header>
            <span class="dot ${w.enabled && w.state === "online" ? "on" : ""}"></span>
            <b>${esc(w.name)}</b>
            <span class="tag">${esc(w.device)} · ${esc(modeLabel(w.mode))}</span>
            <span class="pill ${stateCls(w)}">${stateLabel(w)}</span>
          </header>
          <div class="gauges">
            <div class="gauge g-down">${gaugeSVG()}<div class="gval"><b>0</b><small>⬇ تحميل Mb/s</small></div></div>
            <div class="gauge g-up">${gaugeSVG()}<div class="gval"><b>0</b><small>⬆ رفع Mb/s</small></div></div>
          </div>
          <canvas class="spark"></canvas>
          <div class="lmeta">
            <span>العنوان <b class="mono f-addr">—</b></span>
            <span>البوابة <b class="mono f-gw">—</b></span>
            <span>مدة الاتصال <b class="f-up">—</b></span>
            <span>الوزن <b class="f-w">—</b></span>
            <span>⬇ منذ التشغيل <b class="f-rxb">—</b></span>
            <span>⬆ منذ التشغيل <b class="f-txb">—</b></span>
          </div>
        </article>`).join("") : `<div class="card lempty">ما في خطوط بعد. <a href="#lines" data-go="lines">أضف خط</a></div>`;
      box.insertAdjacentHTML("beforeend", `
        <article class="lcard xcard ${ex0.up ? "" : "off"}" data-if="__exit">
          <header>
            <span class="dot ${ex0.up ? "on" : ""}"></span>
            <b>الخرج (للميكروتك والواي فاي)</b>
            <span class="tag">${esc(c0.exit_port || "—")} · ${c0.exit_mode === "dhcp" ? "DHCP" : "ثابت"}</span>
            <span class="pill ${ex0.up ? "on" : "off"}">${ex0.up ? "موصول" : "المنفذ مفصول"}</span>
          </header>
          <div class="gauges">
            <div class="gauge g-down">${gaugeSVG()}<div class="gval"><b>0</b><small>⬇ للأجهزة Mb/s</small></div></div>
            <div class="gauge g-up">${gaugeSVG()}<div class="gval"><b>0</b><small>⬆ من الأجهزة Mb/s</small></div></div>
          </div>
          <canvas class="spark"></canvas>
          <div class="lmeta">
            <span>عنوان الراوتر <b class="mono x-addr">—</b></span>
            <span>المنافذ <b class="mono x-ports">—</b></span>
            <span>⬇ منذ التشغيل <b class="x-txb">—</b></span>
            <span>⬆ منذ التشغيل <b class="x-rxb">—</b></span>
          </div>
        </article>`);
    }
    const xc = box.querySelector('[data-if="__exit"]');
    if (xc) {
      const eh = S.ehist || [];
      setGauge(xc.querySelector(".g-down"), S.exitRate.rx);
      setGauge(xc.querySelector(".g-up"), S.exitRate.tx);
      xc.querySelector(".x-addr").textContent = (c0.exit_addr || c0.lan_ip || "—").split("/")[0];
      const ports = exitPorts(S.st);
      xc.querySelector(".x-ports").textContent = ports.filter((n) => n !== "__exit").join(" ") || ex0.dev || "—";
      let rb = 0, tb = 0; const dv = S.liveDev || {};
      ports.forEach((n) => { if (dv[n]) { rb += dv[n][0]; tb += dv[n][1]; } });
      if (!S.liveDev) { rb = Number(ex0.rx_bytes) || 0; tb = Number(ex0.tx_bytes) || 0; }
      xc.querySelector(".x-txb").textContent = fmtBytes(tb);
      xc.querySelector(".x-rxb").textContent = fmtBytes(rb);
      drawLines(xc.querySelector(".spark"), [
        { data: eh.map((x) => x.d), color: "#26c98f", fill: "rgba(38,201,143,.22)" },
        { data: eh.map((x) => x.u), color: "#b07cff" },
      ], { floor: 1 });
    }
    wans.forEach((w) => {
      const card = box.querySelector(`[data-if="${CSS.escape(w.iface)}"]`); if (!card) return;
      const r = lineRate(w.iface), h = S.lhist[w.iface] || [];
      const peakD = h.reduce((m, x) => Math.max(m, x.d), r.rx), peakU = h.reduce((m, x) => Math.max(m, x.u), r.tx);
      setGauge(card.querySelector(".g-down"), r.rx);
      setGauge(card.querySelector(".g-up"), r.tx);
      card.querySelector(".f-addr").textContent = (w.addr || "—").split("/")[0];
      card.querySelector(".f-gw").textContent = w.gateway || "—";
      card.querySelector(".f-up").textContent = w.uptime ? fmtDur(w.uptime) : "—";
      card.querySelector(".f-w").textContent = w.weight || "1";
      const tb = lineBytes(w);
      card.querySelector(".f-rxb").textContent = fmtBytes(tb.rx);
      card.querySelector(".f-txb").textContent = fmtBytes(tb.tx);
      drawLines(card.querySelector(".spark"), [
        { data: h.map((x) => x.d), color: "#45a8ff", fill: "rgba(69,168,255,.25)" },
        { data: h.map((x) => x.u), color: "#b07cff" },
      ], { floor: 1 });
    });
  }

  function renderChart() {
    drawLines($("#mainChart"), [
      { data: S.hist.map((x) => x.d), color: "#45a8ff", fill: "rgba(69,168,255,.22)" },
      { data: S.hist.map((x) => x.u), color: "#b07cff", fill: "rgba(176,124,255,.10)" },
    ], { axis: true, floor: 5 });
  }

  function portRole(name) {
    const st = S.st || {}, c = st.cfg || {};
    const w = (st.wans || []).find((x) => x.device === name);
    if (w) return { cls: "r-line", txt: "خط: " + w.name };
    if (name === c.exit_port) return { cls: "r-exit", txt: "خروج الميكروتك" };
    if ((c.mgmt_ports || "").split(/\s+/).includes(name)) return { cls: "r-mgmt", txt: "إدارة" };
    return { cls: "", txt: "فاضي" };
  }
  function renderPorts() {
    const ports = (S.st && S.st.ports) || [];
    $("#ports").innerHTML = ports.map((p) => {
      const r = portRole(p.name);
      const sp = p.up ? (p.speed >= 1000 ? (p.speed / 1000) + "G" : p.speed ? p.speed + "M" : "") : "";
      return `<div class="port ${p.up ? "up" : "down"} ${r.cls}"><div class="pn">${esc(p.name)}</div><div class="pr">${esc(r.txt)}</div><div class="ps">${p.up ? "متصل " + sp : "مفصول"}</div></div>`;
    }).join("");
  }

  /* ---------------- الخطوط ---------------- */
  function renderLines() {
    const wans = (S.st && S.st.wans) || [];
    const body = $("#linesBody");
    const key = wans.map((w) => [w.iface, w.name, w.device, w.mode, w.weight, w.enabled, w.state, w.addr, w.gateway].join("~")).join("|");
    if (key !== S.lineKey || body.children.length !== Math.max(1, wans.length)) {
      S.lineKey = key;
      body.innerHTML = wans.length ? wans.map((w, i) => `
        <tr data-i="${i}">
          <td class="t-name"><b>${esc(w.name)}</b> <span class="pill ${stateCls(w)} t-mstate">${stateLabel(w)}</span></td>
          <td class="mono" data-l="المنفذ">${esc(w.device)}</td>
          <td data-l="النوع">${esc(modeLabel(w.mode))}</td>
          <td class="mono" data-l="العنوان">${esc((w.addr || "—").split("/")[0])}</td>
          <td class="mono" data-l="البوابة">${esc(w.gateway || "—")}</td>
          <td data-l="الوزن">${esc(w.weight || 1)}</td>
          <td class="c-up" data-l="مدة الاتصال">—</td>
          <td class="rx num c-rx" data-l="⬇ تحميل">0</td>
          <td class="tx num c-tx" data-l="⬆ رفع">0</td>
          <td class="t-state"><span class="pill ${stateCls(w)}">${stateLabel(w)}</span></td>
          <td class="actions">
            <button type="button" class="btn xs" data-act="edit" data-i="${i}">تعديل</button>
            <button type="button" class="btn xs" data-act="toggle" data-i="${i}">${w.enabled ? "إيقاف" : "تشغيل"}</button>
            <button type="button" class="btn xs danger ghost" data-act="del" data-i="${i}">حذف</button>
          </td>
        </tr>`).join("") : `<tr><td colspan="11" class="muted" style="text-align:center;padding:1.4rem">ما في خطوط. اضغط "إضافة خط".</td></tr>`;
    }
    wans.forEach((w, i) => {
      const tr = body.querySelector(`tr[data-i="${i}"]`); if (!tr) return;
      const r = lineRate(w.iface);
      tr.querySelector(".c-rx").textContent = fmt(r.rx);
      tr.querySelector(".c-tx").textContent = fmt(r.tx);
      tr.querySelector(".c-up").textContent = w.uptime ? fmtDur(w.uptime) : "—";
    });
  }
  function act(msg, kind) { const el = $("#actMsg"); el.textContent = msg || ""; el.className = "msg " + (kind || ""); }

  // منافذ الإدارة (br-lan): أي منفذ منها بيصير خط، بشرط يضل واحد على الأقل للإدارة
  function mgmtLeft(mg, used, exitPort, extra) {
    return mg.filter((x) => x !== exitPort && x !== extra && !used.has(x)).length;
  }
  function freePorts(current) {
    const st = S.st || {}, c = st.cfg || {};
    const portsLive = (st.ports || []).map((p) => p.name);
    const list = portsLive.length ? portsLive : PORTS_ALL.slice(0, 5);
    const mg = (c.mgmt_ports || "").split(/\s+/).filter(Boolean);
    const used = new Set((st.wans || []).map((w) => w.device).filter((d) => d !== current));
    return list.filter((p) => p === current || (p !== c.exit_port && !used.has(p) && (!mg.includes(p) || mgmtLeft(mg, used, c.exit_port, p) >= 1)));
  }
  function openEdit(i) {
    const wans = (S.st && S.st.wans) || [];
    const w = i == null ? null : wans[i];
    const ports = freePorts(w ? w.device : null);
    if (!w && !ports.length) { act("ما في منفذ فاضي: منفذ الإدارة ومنفذ الخروج محجوزين.", "bad"); toast("ما في منفذ فاضي"); return; }
    S.editIdx = i;
    $("#dlgTitle").textContent = w ? "تعديل خط" : "إضافة خط";
    const f = $("#form");
    $("#dlgPort").innerHTML = ports.map((p) => `<option ${w && p === w.device ? "selected" : ""}>${esc(p)}</option>`).join("");
    f.name.value = w ? w.name : `خط ${wans.length + 1}`;
    f.mode.value = w ? w.mode : "dhcp";
    f.weight.value = w ? (w.weight || 1) : 1;
    f.ip.value = w && w.mode === "static" ? (w.addr || "").split("/")[0] : "";
    f.gw.value = w && w.mode === "static" ? (w.gateway || "") : "";
    f.user.value = w ? (w.username || "") : "";
    f.pass.value = w ? (w.password || "") : "";
    f.mtu.value = w && w.mtu ? w.mtu : "";
    toggleModeFields();
    $("#dlg").showModal();
  }
  function toggleModeFields() {
    const m = $("#form").mode.value;
    $$(".only-static").forEach((el) => el.classList.toggle("hidden", m !== "static"));
    $$(".only-pppoe").forEach((el) => el.classList.toggle("hidden", m !== "pppoe"));
  }

  /* ---------------- حفظ وتطبيق ---------------- */
  function cfgFromForms() {
    const st = S.st || {}, c = Object.assign({}, st.cfg || {});
    const val = (id, d) => { const el = $("#" + id); return el ? el.value : d; };
    return {
      policy: S.policyPick || c.policy || "balanced",
      pin: val("pin", c.pin || "smart"),
      exit_port: val("exitPort", c.exit_port || ""),
      exit_mode: val("exitMode", c.exit_mode || "dhcp"),
      lan_ip: val("lanIp", c.lan_ip || "10.10.10.1"),
      lan_mask: val("lanMask", c.lan_mask || "255.255.255.0"),
      mikrotik_ip: val("mkIp", c.mikrotik_ip || "10.10.10.2"),
      offload: val("offload", c.offload || "soft"),
      track_ips: (val("trackIps", (c.track_ips || []).join("\n")) || "").split(/[\s,]+/).map((x) => x.trim()).filter(Boolean),
    };
  }
  function wansPayload(list) {
    return list.map((w, i) => ({
      name: w.name, iface: `wan${i + 1}`, device: w.device, mode: w.mode,
      weight: Number(w.weight) || 1, enabled: w.enabled !== false,
      ipaddr: w.mode === "static" ? String(w.addr || "").split("/")[0] : "",
      netmask: w.netmask || "255.255.255.0",
      gateway: w.mode === "static" ? (w.gateway || "") : "",
      username: w.mode === "pppoe" ? (w.username || "") : "",
      password: w.mode === "pppoe" ? (w.password || "") : "",
      mtu: w.mtu ? Number(w.mtu) : "",
    }));
  }
  function wifiPayload() {
    return {
      band2: { ssid: $("#wifi2Ssid").value, key: $("#wifi2Key").value, enabled: $("#wifi2Enabled").value !== "0" },
      band5: { ssid: $("#wifi5Ssid").value, key: $("#wifi5Key").value, enabled: $("#wifi5Enabled").value !== "0" },
    };
  }
  function validate(list, cfg) {
    const used = new Set();
    const mg = ((S.st && S.st.cfg && S.st.cfg.mgmt_ports) || "").split(/\s+/).filter(Boolean);
    for (const w of list) {
      if (w.enabled === false) continue;
      if (w.device === cfg.exit_port) return `المنفذ ${w.device} هو منفذ الخروج.`;
      if (used.has(w.device)) return `المنفذ ${w.device} عليه أكتر من خط.`;
      used.add(w.device);
      if (w.mode === "pppoe" && !w.username) return `خط ${w.name}: اكتب اسم مستخدم البرودباند.`;
      if (w.mode === "static" && (!w.addr || !w.gateway)) return `خط ${w.name}: اكتب العنوان والبوابة.`;
    }
    if (mg.length && mgmtLeft(mg, used, cfg.exit_port) < 1) return "لازم يضل منفذ واحد على الأقل للإدارة (للدخول على الراوتر). خفّف خط أو غيّر منفذ الخروج.";
    return "";
  }
  async function commit(list, label, extra) {
    if (!S.loaded) { toast("استنى لحتى يكمل تحميل الإعداد"); return false; }
    if (S.saving) { toast("في أمر عم يتنفّذ، استنى..."); return false; }
    const cfg = cfgFromForms();
    const err = validate(list, cfg);
    if (err) { act(err, "bad"); toast(err); return false; }
    S.saving = true;
    act(label || "عم طبّق على الراوتر...", "");
    toast(label || "عم طبّق على الراوتر...");
    const body = Object.assign({ cfg, wans: wansPayload(list) }, extra || {});
    try {
      const d = await api("apply", body);
      act("تم التطبيق ✓", "ok"); toast("تم التطبيق ✓");
      S.saving = false; S.formDirty = {};
      setTimeout(poll, 600);
      return d;
    } catch (e) {
      S.saving = false;
      if (!e.fromRouter) {
        // انقطاع لحظي (الشبكة عم تتحمّل من جديد): نتأكد إذا انحفظ
        await new Promise((r) => setTimeout(r, 2500));
        try { await poll(); act("تم الحفظ — الراوتر عم يحمّل الشبكة", "ok"); return true; } catch (_) { }
      }
      act(String(e.message || e), "bad"); toast(String(e.message || e));
      return false;
    }
  }
  const currentList = () => ((S.st && S.st.wans) || []).map((w) => Object.assign({}, w));

  /* ---------------- الإعداد / الخروج / الواي فاي ---------------- */
  function fillForms(force) {
    const st = S.st; if (!st) return;
    const c = st.cfg || {};
    const setv = (id, v) => { const el = $("#" + id); if (el && (force || (!S.formDirty[id] && document.activeElement !== el))) el.value = v; };
    const ports = (st.ports || []).map((p) => p.name);
    const mg = (c.mgmt_ports || "").split(/\s+/).filter(Boolean);
    const wused = new Set((st.wans || []).map((w) => w.device));
    const ep = $("#exitPort");
    const exitOpts = (ports.length ? ports : PORTS_ALL.slice(0, 5)).filter((p) => p === c.exit_port || (!wused.has(p) && (!mg.includes(p) || mgmtLeft(mg, wused, "", p) >= 1)));
    const optKey = exitOpts.join(",");
    if (ep.dataset.k !== optKey) { ep.innerHTML = exitOpts.map((p) => `<option>${esc(p)}</option>`).join(""); ep.dataset.k = optKey; }
    setv("exitPort", c.exit_port || exitOpts[exitOpts.length - 1] || "");
    setv("exitMode", c.exit_mode || "dhcp");
    setv("lanIp", c.lan_ip || "10.10.10.1");
    setv("lanMask", c.lan_mask || "255.255.255.0");
    setv("mkIp", c.mikrotik_ip || "10.10.10.2");
    setv("pin", c.pin || "smart");
    setv("offload", c.offload || "soft");
    setv("trackIps", (c.track_ips || []).join("\n"));
    $("#offloadState").textContent = "الحالة: " + (c.offload_state || "—");
    if (!S.policyPick || force) S.policyPick = c.policy || "balanced";
    renderPolicies();
    const wf = st.wifi || {};
    if (wf.band2) { setv("wifi2Ssid", wf.band2.ssid || ""); setv("wifi2Key", wf.band2.key || ""); setv("wifi2Enabled", wf.band2.enabled === false ? "0" : "1"); }
    if (wf.band5) { setv("wifi5Ssid", wf.band5.ssid || ""); setv("wifi5Key", wf.band5.key || ""); setv("wifi5Enabled", wf.band5.enabled === false ? "0" : "1"); }
    $("#wifiNet").textContent = wf.network === "sbexit" ? `الواي فاي على شبكة الخروج (${(c.lan_ip || "")}) ويطلع من الدمج` : "الواي فاي على شبكة الإدارة";
    $("#authOffBox").hidden = !st.auth_off;
    $("#btnAuthOff").hidden = !!st.auth_off;
    $("#btnLogout").hidden = !!st.auth_off;
    renderExitInfo();
  }
  function renderPolicies() {
    const items = [["balanced", "متساوٍ (دمج)", "كل اتصال جديد بيروح على خط حي حسب الوزن — بتستعمل كل الخطوط سوا"], ["failover", "احتياط", "خط أساسي واحد، والباقي بيستنى ليسقط"]];
    $("#policies").innerHTML = items.map(([id, t, d]) => `<div class="choice ${S.policyPick === id ? "active" : ""}" data-policy="${id}"><b>${t}</b><span>${d}</span></div>`).join("");
  }
  function renderExitInfo() {
    const c = (S.st && S.st.cfg) || {};
    const mode = $("#exitMode").value, ip = $("#lanIp").value || c.lan_ip, mk = $("#mkIp").value || c.mikrotik_ip;
    const dns = ($("#mkDns").value || "1.1.1.1,8.8.8.8").replace(/\s/g, "");
    $("#exitLive").textContent = `العنوان الحالي: ${(c.exit_addr || "—")} · الوضع: ${c.exit_mode === "dhcp" ? "DHCP" : "ثابت"}`;
    $("#mkCode").textContent = mode === "dhcp"
      ? `# الراوتر ${ip} بيعطي الميكروتك IP وبوابة تلقائياً\n/ip dhcp-client add interface=ether1 disabled=no add-default-route=yes use-peer-dns=no\n/ip dns set servers=${dns}`
      : `/ip address add address=${mk}/24 interface=ether1\n/ip route add dst-address=0.0.0.0/0 gateway=${ip}\n/ip dns set servers=${dns}`;
  }

  /* ---------------- فحص السرعة ---------------- */
  function renderSpeed(d) {
    const lines = (d && d.lines) || [];
    const phases = { select: "عم يختار سيرفر شغّال لكل خط...", each: "عم يفحص كل خط لحاله...", all: "عم يفحص كل الخطوط سوا...", done: "خلص الفحص ✓", none: "خلص" };
    $("#spState").textContent = d.error ? d.error : (d.state === "running" ? phases[d.phase] || "شغّال..." : d.state === "done" ? "خلص الفحص ✓" : "جاهز.");
    const prog = d.state === "done" ? 100 : d.phase === "select" ? 15 : d.phase === "each" ? 30 + 50 * (lines.filter((l) => l.each != null).length / Math.max(1, lines.length)) : d.phase === "all" ? 85 : 5;
    $("#spBar").style.width = (d.state === "idle" ? 0 : prog) + "%";
    const max = Math.max(1, ...lines.map((l) => Math.max(Number(l.each) || 0, Number(l.all) || 0)));
    $("#spTotal").innerHTML = d.total != null ? `<div class="card"><div><div class="muted">المجموع — كل الخطوط سوا</div><div class="big">${fmt(d.total)}<em>Mb/s</em></div></div><div class="muted small">${lines.length} خط · مدة ${d.seconds} ثانية لكل فحص</div></div>` : "";
    $("#spLines").innerHTML = lines.map((l) => {
      const bar = (v, cls, lbl) => v == null ? "" : `<div class="sp-row ${cls}"><span>${lbl}</span><div class="bar"><i style="width:${Math.min(100, (Number(v) || 0) / max * 100)}%"></i></div><b>${fmt(v)} Mb/s</b></div>`;
      return `<article class="card sp-card"><h3><span class="dot ${l.server ? "on" : ""}"></span>${esc(l.name)} <span class="tag">${esc(l.dev)}</span></h3>
        <div class="srv">${l.server ? "سيرفر: " + esc(l.server) : "—"}</div>
        ${bar(l.each, "", "لحاله")}${bar(l.all, "all", "مع الكل")}
        ${l.note ? `<div class="sp-note">⚠️ ${esc(l.note)}</div>` : ""}</article>`;
    }).join("");
  }
  function renderSpeedLive() {
    const el = $("#spLive"); if (!el) return;
    const wans = ((S.st && S.st.wans) || []).filter((w) => w.enabled);
    const key = wans.map((w) => w.iface + "~" + w.name).join("|");
    if (el.dataset.key !== key) {
      el.dataset.key = key;
      el.innerHTML = wans.length ? `<div class="card sp-meter">
        <div class="gauge g-down big">${gaugeSVG()}<div class="gval"><b>0</b><small>⬇ تحميل الآن · Mb/s</small></div></div>
        <div class="sp-side">
          <div class="sp-phase" id="spPhase">مباشر</div>
          ${wans.map((w) => `<div class="sp-lrow" data-if="${esc(w.iface)}"><span class="nm">${esc(w.name)}</span><b class="v">0</b><div class="bar"><i></i></div></div>`).join("")}
        </div></div>` : "";
    }
    if (!wans.length) return;
    const t = totals();
    const recent = S.hist.slice(-60);
    setGauge(el.querySelector(".gauge.big"), t.d);
    const sp = S.sp && S.sp.state === "running" ? S.sp : null;
    let curIf = null;
    if (sp && sp.phase === "each") curIf = sp.cur || ((sp.lines || []).find((l) => l.each == null) || {}).iface || null;
    let lmax = 1;
    wans.forEach((w) => { lmax = Math.max(lmax, lineRate(w.iface).rx, ...(S.lhist[w.iface] || []).slice(-60).map((x) => x.d)); });
    lmax = niceMax(lmax, 10);
    wans.forEach((w) => {
      const row = el.querySelector(`.sp-lrow[data-if="${CSS.escape(w.iface)}"]`); if (!row) return;
      const r = lineRate(w.iface).rx;
      row.querySelector(".v").textContent = fmt(r) + " Mb/s";
      row.querySelector(".bar i").style.width = Math.min(100, r / lmax * 100) + "%";
      row.classList.toggle("active", !!sp && (sp.phase === "all" || curIf === w.iface));
    });
    let txt = "مباشر · السحب الحالي على كل خط";
    if (sp) {
      const nm = curIf ? ((wans.find((w) => w.iface === curIf) || {}).name || curIf) : "";
      txt = sp.phase === "select" ? "عم يجهّز سيرفر لكل خط..." : sp.phase === "each" ? `عم يفحص ${nm} لحاله` : sp.phase === "all" ? "عم يفحص كل الخطوط سوا" : "الفحص شغّال...";
      if (sp.t0 != null && S.liveTs && sp.phase !== "select") {
        const secs = Math.max(0, Math.min(Number(sp.seconds) || 10, S.liveTs - Number(sp.t0)));
        txt += ` · ${Math.floor(secs)} / ${sp.seconds} ث`;
      }
    }
    $("#spPhase").textContent = txt;
  }
  async function pollSpeed() {
    try {
      const d = await api("speedtest_status");
      S.sp = d;
      renderSpeed(d);
      renderSpeedLive();
      if (d.state === "running") { S.speedTimer = setTimeout(pollSpeed, 1000); return; }
    } catch (e) { $("#spState").textContent = String(e.message || e); }
    S.speedTimer = null; $("#btnSpEach").disabled = $("#btnSpAll").disabled = $("#tbSpeed").disabled = false;
  }
  async function startSpeed(mode) {
    if (S.speedTimer) return;
    view("speed");
    $("#btnSpEach").disabled = $("#btnSpAll").disabled = $("#tbSpeed").disabled = true;
    $("#spLines").innerHTML = ""; $("#spTotal").innerHTML = ""; $("#spBar").style.width = "3%";
    $("#spState").textContent = "عم يبلش...";
    try {
      await api("speedtest_start", { mode, seconds: Number($("#spSecs").value) || 10 });
      S.speedTimer = setTimeout(pollSpeed, 700);
    } catch (e) {
      $("#spState").textContent = String(e.message || e);
      $("#btnSpEach").disabled = $("#btnSpAll").disabled = $("#tbSpeed").disabled = false;
    }
  }

  /* ---------------- الأدوات ---------------- */
  async function doPing() {
    const out = $("#pingOut"); out.textContent = "عم يفحص (حوالي 10 ثواني)...";
    try {
      const d = await api("ping");
      const names = {}; ((S.st && S.st.wans) || []).forEach((w) => { names[w.iface] = w.name; });
      out.innerHTML = d.results.length ? `<table class="tbl"><thead><tr><th>الخط</th><th>الجهاز</th><th>فقد</th><th>متوسط</th><th>الحالة</th></tr></thead><tbody>${d.results.map((r) => `
        <tr><td><b>${esc(names[r.iface] || r.iface)}</b></td><td class="mono">${esc(r.dev)}</td>
        <td class="${r.loss >= 100 ? "bad-t" : r.loss > 0 ? "" : "ok-t"}">${r.loss}%</td><td class="mono">${r.avg ? esc(r.avg) + " ms" : "—"}</td>
        <td><span class="pill ${r.state === "online" ? "on" : "off"}">${r.state === "online" ? "متصل" : "ساقط"}</span></td></tr>`).join("")}</tbody></table>` : "ما في خطوط.";
    } catch (e) { out.textContent = String(e.message || e); }
  }
  function renderNet(d) {
    const lines = d.lines || [];
    $("#netOut").innerHTML = (d.state === "running" ? `<p class="muted">عم يفحص... (${lines.length} خط خلص)</p>` : "") + lines.map((l) => `
      <div class="nt-line">
        <h4><span class="dot ${l.state === "online" ? "on" : ""}"></span>${esc(l.name)} <span class="tag">${esc(l.dev)}</span>
          <span class="small ${l.small && l.small.ok ? "ok-t" : "bad-t"}">صفحة صغيرة: ${l.small && l.small.ok ? "تمام" : "فشل"}</span></h4>
        <table class="tbl"><tbody>${(l.tests || []).map((t) => `<tr><td class="mono">${esc(t.host)}${/^https/.test(t.url) ? " (https)" : ""}</td>
          <td class="num ${Number(t.mbps) > 0.3 ? "ok-t" : "bad-t"}">${fmt(t.mbps)} Mb/s</td><td class="muted small">${esc(t.err || "")}</td></tr>`).join("")}</tbody></table>
        ${l.hint ? `<div class="nt-hint">⚠️ ${esc(l.hint)}</div>` : ""}
      </div>`).join("");
  }
  async function pollNet() {
    try {
      const d = await api("nettest_status");
      renderNet(d);
      if (d.state === "running") { S.netTimer = setTimeout(pollNet, 2500); return; }
    } catch (e) { $("#netOut").textContent = String(e.message || e); }
    S.netTimer = null; $("#btnNettest").disabled = false;
  }

  /* ---------------- السجل والنظام ---------------- */
  function renderLog() {
    const ev = ((S.st && S.st.events) || []).slice().reverse();
    $("#logBody").innerHTML = ev.length ? ev.map((e) => `<tr><td class="mono muted">${esc(e.t)}</td><td>${esc(e.msg)}</td></tr>`).join("") : `<tr><td colspan="2" class="muted">لا أحداث.</td></tr>`;
  }
  function renderSys() {
    const st = S.st; if (!st) return;
    const c = st.cfg || {};
    $("#sysInfo").innerHTML = `
      <dt>الإصدار</dt><dd>Starbond ${esc(st.version)}</dd>
      <dt>اسم الراوتر</dt><dd>${esc(st.hostname)}</dd>
      <dt>مدة التشغيل</dt><dd>${fmtDur(st.uptime_s)}</dd>
      <dt>الذاكرة</dt><dd>${st.ram_used_mb} / ${st.ram_total_mb} MB</dd>
      <dt>التسريع</dt><dd>${esc(c.offload_state || "—")}</dd>
      <dt>منافذ الإدارة</dt><dd class="mono">${esc(c.mgmt_ports || "—")}</dd>`;
  }

  /* ---------------- الدورة ---------------- */
  function renderView() {
    if (!S.st) return;
    renderTop();
    if (S.view === "dash") { renderKpis(); renderCards(); renderChart(); renderPorts(); }
    if (S.view === "lines") renderLines();
    if (S.view === "speed") renderSpeedLive();
    if (S.view === "log") renderLog();
    if (S.view === "system") renderSys();
    if (["exit", "wifi", "settings"].includes(S.view) && !S.saving) fillForms(false);
  }
  function renderLive() {
    if (!S.st) return;
    renderTopRates();
    if (S.view === "dash") { renderKpis(); renderCards(); renderChart(); }
    else if (S.view === "lines") renderLines();
    else if (S.view === "speed") renderSpeedLive();
  }
  async function poll() {
    if (!S.authed) return;
    const st = await api("status");
    if (st.version && st.version !== UI_VER && /^\d+\.\d+/.test(st.version)) {
      try {
        const k = "sb_reload_" + st.version;
        if (!sessionStorage.getItem(k)) { sessionStorage.setItem(k, "1"); location.replace("/starbond/?v=" + encodeURIComponent(st.version) + location.hash); }
      } catch (_) { }
    }
    S.st = st;
    if (S.noLive) sample(liveFromStatus(st));
    if (!S.loaded) { S.loaded = true; fillForms(true); }
    renderView();
    return st;
  }
  let pollTimer = null, liveTimer = null, liveFails = 0;
  function loop() {
    clearTimeout(pollTimer);
    poll().catch(() => { }).finally(() => { pollTimer = setTimeout(loop, S.noLive ? 2000 : POLL_MS); });
    if (!liveTimer && !S.liveBusy && !S.noLive) liveLoop();
  }
  // البث اللحظي: الراوتر بيكتب لقطة بالـ RAM كل ربع ثانية، ومنقراها كملف ثابت (بدون CGI)
  async function rtOn() {
    const now = Date.now();
    if (S.rtAsk && now - S.rtAsk < 4000) return;
    S.rtAsk = now;
    try { const d = await api("live_on"); if (d && d.url) S.rt = { url: d.url, ms: Number(d.ms) || RT_MS, seen: now, ts: 0 }; }
    catch (_) { /* نظام قديم: منضل على CGI */ }
  }
  async function pollRt() {
    const r = await fetch(S.rt.url + "?" + Date.now(), { cache: "no-store", credentials: "same-origin" });
    if (!r.ok) throw new Error("rt " + r.status);
    const lv = await r.json();
    const now = Date.now();
    if (Number(lv.ts) > S.rt.ts) { S.rt.ts = Number(lv.ts); S.rt.seen = now; }
    else if (now - S.rt.seen > 2500) throw new Error("rt stale");   // الكاتب وقف
    return lv;
  }
  async function pollLive() {
    if (!S.authed || S.noLive) return;
    if (!S.rt) rtOn();
    try {
      let lv;
      if (S.rt) {
        try { lv = await pollRt(); }
        catch (_) { S.rt = null; rtOn(); }
      }
      if (!lv) lv = await api("live");          // احتياط لحد ما يرجع البث
      liveFails = 0;
      sample(lv);
      renderLive();
    } catch (e) {
      if (e && e.fromRouter && ++liveFails >= 3) S.noLive = true;   // نظام قديم ما فيه live
    }
  }
  function liveLoop() {
    if (S.liveBusy) return;
    clearTimeout(liveTimer); liveTimer = null;
    S.liveBusy = true;
    pollLive().finally(() => {
      S.liveBusy = false;
      if (!S.noLive) liveTimer = setTimeout(liveLoop, document.hidden ? 5000 : S.rt ? (S.rt.ms || RT_MS) : LIVE_MS);
    });
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden && S.authed && !S.noLive) liveLoop(); });
  function view(name) {
    if (!$(`.view[data-view="${name}"]`)) name = "dash";
    S.view = name;
    $$(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.view === name));
    $$(".view").forEach((v) => v.classList.toggle("active", v.dataset.view === name));
    $("#sidebar").classList.remove("open");
    if (location.hash !== "#" + name) history.replaceState(null, "", "#" + name);
    if (["exit", "wifi", "settings"].includes(name)) fillForms(true);
    if (name === "tools" && S.authed && !$("#appOut").textContent.includes("ما انحفظت")) loadApps();
    renderView();
  }

  /* ---------------- الأحداث ---------------- */
  document.addEventListener("click", (e) => {
    const go = e.target.closest("[data-go]");
    if (go) { e.preventDefault(); view(go.dataset.go); return; }
    const nav = e.target.closest(".nav a");
    if (nav) { e.preventDefault(); view(nav.dataset.view); }
  });
  $("#sideToggle").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
  $("#sideBackdrop").addEventListener("click", () => $("#sidebar").classList.remove("open"));
  $("#sideExit").addEventListener("click", () => view("exit"));
  $("#tbSpeed").addEventListener("click", () => startSpeed("each"));
  $("#btnSpEach").addEventListener("click", () => startSpeed("each"));
  $("#btnSpAll").addEventListener("click", () => startSpeed("all"));
  ["exitPort", "exitMode", "lanIp", "lanMask", "mkIp", "mkDns", "pin", "offload", "trackIps", "wifi2Ssid", "wifi2Key", "wifi2Enabled", "wifi5Ssid", "wifi5Key", "wifi5Enabled"].forEach((id) => {
    const el = $("#" + id); if (!el) return;
    el.addEventListener("input", () => { S.formDirty[id] = true; if (["exitMode", "lanIp", "mkIp", "mkDns"].includes(id)) renderExitInfo(); });
    el.addEventListener("change", () => { S.formDirty[id] = true; renderExitInfo(); });
  });
  $("#policies").addEventListener("click", (e) => {
    const c = e.target.closest("[data-policy]"); if (!c) return;
    S.policyPick = c.dataset.policy; renderPolicies();
  });

  // الخطوط
  $("#btnAdd").addEventListener("click", () => openEdit(null));
  $("#form").mode.addEventListener("change", toggleModeFields);
  $("#dlgCancel").addEventListener("click", () => $("#dlg").close());
  $("#form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = $("#form");
    if (!f.reportValidity()) return;
    const list = currentList();
    const item = {
      name: f.name.value.trim() || "خط", device: f.port.value, mode: f.mode.value,
      weight: Math.min(20, Math.max(1, Number(f.weight.value) || 1)),
      enabled: true, addr: f.ip.value.trim(), gateway: f.gw.value.trim(),
      username: f.user.value, password: f.pass.value, mtu: f.mtu.value ? Number(f.mtu.value) : "",
    };
    if (S.editIdx == null) list.push(item);
    else { item.enabled = list[S.editIdx].enabled; list[S.editIdx] = Object.assign(list[S.editIdx], item); }
    $("#dlg").close();
    await commit(list, S.editIdx == null ? "عم ضيف الخط..." : "عم عدّل الخط...");
  });
  function confirmBox(title, text) {
    return new Promise((res) => {
      $("#cfmTitle").textContent = title; $("#cfmText").textContent = text;
      const d = $("#cfm");
      const done = (v) => { d.close(); $("#cfmYes").onclick = $("#cfmNo").onclick = null; res(v); };
      $("#cfmYes").onclick = () => done(true); $("#cfmNo").onclick = () => done(false);
      d.showModal();
    });
  }
  $("#linesBody").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const i = Number(b.dataset.i); const list = currentList(); const w = list[i]; if (!w) return;
    if (b.dataset.act === "edit") return openEdit(i);
    if (b.dataset.act === "toggle") { w.enabled = !w.enabled; return commit(list, w.enabled ? "عم شغّل الخط..." : "عم وقّف الخط..."); }
    if (b.dataset.act === "del") {
      if (!(await confirmBox("حذف خط", `أكيد بدك تحذف "${w.name}" (${w.device})؟`))) return;
      list.splice(i, 1);
      return commit(list, "عم احذف الخط...");
    }
  });

  // الخروج والإعداد والواي فاي
  $("#btnSaveExit").addEventListener("click", () => commit(currentList(), "عم طبّق الخروج..."));
  $("#btnSaveSettings").addEventListener("click", () => commit(currentList(), "عم طبّق الإعداد..."));
  $("#btnSaveWifi").addEventListener("click", async () => {
    $("#wifiOut").textContent = "عم طبّق...";
    const ok = await commit(currentList(), "عم طبّق الواي فاي...", { wifi: wifiPayload() });
    $("#wifiOut").textContent = ok ? "تم ✓ (الواي فاي بينقطع ثواني)" : "";
  });
  $("#btnCopyMk").addEventListener("click", () => {
    const t = $("#mkCode").textContent;
    (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("انتسخت ✓")).catch(() => toast("انسخها يدوياً"));
  });

  // كلمة السر
  $("#btnPasswd").addEventListener("click", async () => {
    const out = $("#pwOut");
    const o = $("#pwOld").value, n1 = $("#pwNew").value, n2 = $("#pwNew2").value;
    if (n1.length < 6) { out.textContent = "الجديدة لازم 6 أحرف أو أكتر"; return; }
    if (n1 !== n2) { out.textContent = "التأكيد ما بيطابق"; return; }
    try { const d = await api("passwd", { old: o, new: n1 }); out.textContent = d.message || "تم"; $("#pwOld").value = $("#pwNew").value = $("#pwNew2").value = ""; }
    catch (e) { out.textContent = String(e.message || e); }
  });
  $("#btnAuthOff").addEventListener("click", async () => {
    if (!(await confirmBox("إيقاف كلمة السر", "أي حدا على الشبكة رح يقدر يغيّر الإعدادات. متأكد؟"))) return;
    try { const d = await api("auth_disable", {}); toast(d.message || "تم"); poll(); } catch (e) { toast(String(e.message || e)); }
  });
  $("#btnAuthOn").addEventListener("click", async () => {
    try { const d = await api("auth_enable", {}); toast(d.message || "تم"); poll(); } catch (e) { toast(String(e.message || e)); }
  });
  $("#btnLogout").addEventListener("click", async () => { try { await api("logout", {}); } catch (_) { } S.authed = false; showAuth("login"); });

  // الأدوات
  $("#btnPing").addEventListener("click", doPing);
  $("#btnNettest").addEventListener("click", async () => {
    if (S.netTimer) return;
    $("#btnNettest").disabled = true; $("#netOut").innerHTML = `<p class="muted">عم يبلش...</p>`;
    try { await api("nettest_start", {}); S.netTimer = setTimeout(pollNet, 2500); }
    catch (e) { $("#netOut").textContent = String(e.message || e); $("#btnNettest").disabled = false; }
  });
  $("#btnDiag").addEventListener("click", async () => {
    $("#diagOut").textContent = "عم يجمع...";
    try { $("#diagOut").textContent = await api("diag", null, { text: true }); } catch (e) { $("#diagOut").textContent = String(e.message || e); }
  });
  $("#btnDiagCopy").addEventListener("click", () => {
    const t = $("#diagOut").textContent;
    (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("انتسخ التقرير ✓")).catch(() => toast("انسخه يدوياً"));
  });

  // النظام
  $("#btnApplyAll").addEventListener("click", () => commit(currentList(), "عم يعيد التطبيق..."));
  $("#btnRollback").addEventListener("click", async () => {
    if (!(await confirmBox("رجوع", "ترجع إعدادات الشبكة لآخر نسخة احتياطية؟"))) return;
    $("#maintOut").textContent = "عم يرجع...";
    try { const d = await api("rollback", {}); $("#maintOut").textContent = d.message || "تم"; } catch (e) { $("#maintOut").textContent = String(e.message || e); }
  });
  $("#btnReboot").addEventListener("click", async () => {
    if (!(await confirmBox("إعادة تشغيل", "الراوتر رح ينطفي ويرجع خلال دقيقة تقريباً. متأكد؟"))) return;
    try { const d = await api("reboot", {}); $("#maintOut").textContent = d.message || "عم يعيد التشغيل"; } catch (e) { $("#maintOut").textContent = String(e.message || e); }
  });
  async function luciState(set) {
    try {
      const d = await api("luci", set == null ? { on: "state" } : { on: set });
      $("#luciState").textContent = d.luci === "off" ? "متوقفة (واجهة وحدة)" : "شغّالة";
      $("#btnLuci").dataset.on = d.luci === "off" ? "false" : "true";
      if (d.message) $("#maintOut").textContent = d.message;
    } catch (e) { $("#luciState").textContent = "—"; }
  }
  $("#btnLuci").addEventListener("click", () => luciState($("#btnLuci").dataset.on === "true" ? false : true));
  $("#btnOsInstall").addEventListener("click", async () => {
    const f = $("#osFile").files && $("#osFile").files[0];
    if (!f) { toast("اختار ملف التحديث أول"); return; }
    $("#osOut").textContent = `عم يرفع ${f.name} (${Math.round(f.size / 1024)} KB)...`;
    try {
      const buf = await f.arrayBuffer();
      const r = await fetch(`${API}?action=os_install`, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/octet-stream" }, body: buf });
      const text = await r.text(); let d;
      try { d = JSON.parse(text); } catch (_) { throw new Error(text.slice(0, 200)); }
      if (!d.ok) throw new Error(d.error || "فشل");
      const m = /version=([0-9][0-9.]*)/.exec(d.message || "");
      $("#osOut").textContent = (d.message || "تم التثبيت") + "\n\nالصفحة رح تتحدّث لحالها بعد 20 ثانية...";
      toast("تم التثبيت ✓");
      // حمّل الواجهة الجديدة (رابط جديد حتى المتصفح ما يستعمل النسخة القديمة المحفوظة)
      setTimeout(() => location.replace("/starbond/?v=" + encodeURIComponent(m ? m[1] : String(Date.now())) + location.hash), 20000);
    } catch (e) { $("#osOut").textContent = String(e.message || e); toast("فشل التثبيت"); }
  });

  /* حركة فعلية لكل تطبيق من جدول اتصالات الراوتر (مش تقدير) */
  function fmtRate(bps) { const m = bps * 8 / 1e6; return m >= 1 ? m.toFixed(1) + " Mb/s" : (m * 1000).toFixed(0) + " kb/s"; }
  async function appsTraffic() {
    if (S.view !== "tools" || document.hidden || !S.apps) return;
    let d; try { d = await api("apps_traffic"); } catch (_) { return; }
    if (!d || !d.ok) return;
    const names = {}; (S.apps.lines || []).forEach((l) => { names[l.mark] = l.name || l.iface; });
    const prev = S.appsPrev || {}, cur = {}, by = {};
    const dt = S.appsPrevTs ? Math.max(0.5, d.ts - S.appsPrevTs) : 0;
    for (const it of d.items) {
      const k = it.app + ":" + it.mark; cur[k] = it;
      const p = prev[k];
      const rup = p && dt ? Math.max(0, it.up - p.up) / dt : 0, rdn = p && dt ? Math.max(0, it.down - p.down) / dt : 0;
      (by[it.app] = by[it.app] || []).push({ line: names[it.mark] || ("0x" + it.mark.toString(16)), conns: it.conns, rup, rdn, tot: it.up + it.down });
    }
    S.appsPrev = cur; S.appsPrevTs = d.ts;
    $$("#appList .live").forEach((el) => {
      const num = +el.dataset.live, row = el.closest(".approw");
      const on = row && row.querySelector('[data-k="enabled"]') && row.querySelector('[data-k="enabled"]').checked;
      const xs = (by[num] || []).sort((a, b) => b.conns - a.conns);
      if (!num || !on) { el.innerHTML = ""; return; }
      if (!xs.length) { el.innerHTML = `<span class="muted">مباشر: ما في اتصالات لهالتطبيق هلق</span>`; return; }
      el.innerHTML = "مباشر: " + xs.map((x) => `<b>${esc(x.line)}</b> ${x.conns} اتصال` +
        (dt ? ` <span class="muted">⬇ ${fmtRate(x.rdn)} ⬆ ${fmtRate(x.rup)}</span>` : "")).join(" · ") +
        (d.acct ? "" : ` <span class="muted">(عدّاد البايتات مطفي)</span>`);
    });
  }
  setInterval(appsTraffic, 2000);

  /* ---------------- الترخيص ---------------- */
  const LIC_LABEL = { active: "مرخّص", trial: "فترة تجربة", expired: "منتهي", suspended: "موقوف", unregistered: "غير مرخّص", pending: "بانتظار التفعيل", none: "—" };
  const LIC_CLS = { active: "on", trial: "on", expired: "off", suspended: "off", unregistered: "off", pending: "dis" };
  function fmtDay(t) { return t ? new Date(t * 1000).toLocaleDateString("ar-SY-u-nu-latn", { year: "numeric", month: "short", day: "numeric" }) : "—"; }
  function renderLic(d) {
    S.lic = d;
    if (!d || d.status === "none") return;
    const st = d.status;
    const pill = $("#licPill"); pill.textContent = LIC_LABEL[st] || st; pill.className = "pill " + (LIC_CLS[st] || "dis");
    const rows = [["رقم الجهاز", `<span class="lic-id">${esc(d.id_fmt || "—")}</span>`]];
    if (d.customer) rows.push(["الزبون", esc(d.customer)]);
    if (d.expires) rows.push(["ينتهي", esc(fmtDay(d.expires)) + (d.licensed && d.days_left ? ` <span class="muted small">(باقي ${d.days_left} يوم)</span>` : "")]);
    else if (st === "pending" && d.days_left) rows.push(["سماح مؤقت", `باقي ${d.days_left} يوم`]);
    rows.push(["الدمج", d.bonding ? "شغّال" : (d.licensed ? "—" : "موقوف")]);
    if (d.checked) rows.push(["آخر تحقق", esc(new Date(d.checked * 1000).toLocaleString("ar-SY-u-nu-latn"))]);
    $("#licInfo").innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v}</dd>`).join("");
    let out = d.message || "";
    if (d.error) out += (out ? "\n" : "") + "⚠️ " + d.error;
    if (!d.licensed) out += (out ? "\n" : "") + "ابعت رقم الجهاز للمزوّد ليفعّل الاشتراك.";
    $("#licOut").textContent = out || "—";
    // الشريط فوق
    const bn = $("#licBanner");
    if (!d.licensed) {
      bn.className = "banner bad inline"; bn.hidden = false;
      $("#licBannerTxt").innerHTML = `⛔ هالجهاز <b>${esc(LIC_LABEL[st] || "غير مرخّص")}</b> — دمج الخطوط موقوف. رقم الجهاز: <span class="lic-id">${esc(d.id_fmt || "")}</span>`;
    } else if ((st === "trial" || st === "pending" || st === "active") && d.days_left && d.days_left <= 7) {
      bn.className = "banner trial inline"; bn.hidden = false;
      $("#licBannerTxt").innerHTML = st === "active"
        ? `⏳ الاشتراك بيخلص بعد <b>${d.days_left}</b> يوم — جدّد مع المزوّد. رقم الجهاز: <span class="lic-id">${esc(d.id_fmt || "")}</span>`
        : `🧪 ${esc(LIC_LABEL[st])}: باقي <b>${d.days_left}</b> يوم. رقم الجهاز: <span class="lic-id">${esc(d.id_fmt || "")}</span>`;
    } else bn.hidden = true;
  }
  async function licLoad(action) {
    try {
      const d = await api(action || "license_status");
      renderLic(d);
      if (d.checking) setTimeout(() => licLoad("license_status"), 6000);
    } catch (e) { $("#licOut").textContent = String(e.message || e); }
  }
  $("#btnLicCheck").addEventListener("click", () => { $("#licOut").textContent = "عم يتحقق..."; licLoad("license_check"); });
  $("#btnLicCopy").addEventListener("click", async () => {
    const id = S.lic && S.lic.id_fmt; if (!id) return;
    try { await navigator.clipboard.writeText(id); toast("انسخ ✓"); } catch (_) { toast(id); }
  });

  /* ---------------- التحديث التلقائي (GitHub) ---------------- */
  const UP_BUSY = ["checking", "downloading", "installing"];
  const UP_LABEL = { idle: "—", checking: "عم يفحص", downloading: "عم ينزّل", installing: "عم يركّب", available: "في تحديث", uptodate: "محدّث", done: "تم التحديث", error: "خطأ", rolledback: "رجع للقديم", none: "غير مركّبة" };
  const UP_CLS = { available: "off", uptodate: "on", done: "on", error: "off", rolledback: "off" };
  const VERIFY_LABEL = { signature: "توقيع رقمي ✓", https: "بصمة الملف ✓" };
  (function () { const h = $("#upHour"); for (let i = 0; i < 24; i++) h.insertAdjacentHTML("beforeend", `<option value="${i}">${String(i).padStart(2, "0")}:00</option>`); })();
  function renderUp(d, fillForm) {
    const st = d.state || "idle";
    const pill = $("#upPill"); pill.textContent = UP_LABEL[st] || st; pill.className = "pill " + (UP_CLS[st] || "dis");
    const rows = [["النسخة الحالية", d.current || "—"], ["آخر نسخة", d.latest || "—"], ["آخر فحص", d.checked || "—"]];
    if (d.applied) rows.push(["آخر تحديث", d.applied]);
    if (d.verified) rows.push(["التحقق", VERIFY_LABEL[d.verified] || d.verified]);
    $("#upInfo").innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd dir="auto">${esc(v)}</dd>`).join("");
    let msg = d.message || "";
    if (UP_BUSY.includes(st) && d.progress) msg += `  (${d.progress}%)`;
    if (d.notes && (st === "available" || st === "done")) msg += `\n\nالجديد:\n${d.notes}`;
    $("#upOut").textContent = msg || "—";
    const bn = $("#upBanner"), busy = UP_BUSY.includes(st) && st !== "checking";
    bn.hidden = !(d.available || busy);
    $("#upBannerVer").textContent = d.latest || "";
    $("#upBannerMsg").textContent = busy ? `— ${d.message || ""}${d.progress ? ` (${d.progress}%)` : ""}` : "";
    $("#btnUpBanner").disabled = busy;
    $("#btnUpApply").disabled = !d.available || UP_BUSY.includes(st);
    $("#btnUpCheck").disabled = UP_BUSY.includes(st);
    if (fillForm) {
      $("#upRepo").value = d.repo || "";
      $("#upChannel").value = d.channel === "beta" ? "beta" : "stable";
      $("#upAuto").value = d.auto === "1" ? "1" : "0";
      $("#upHour").value = /^\d+$/.test(d.hour || "") ? String(Number(d.hour)) : "4";
    }
  }
  async function upLoad(fillForm) {
    try {
      const d = await api("update_status"); S.up = d; renderUp(d, fillForm);
      // الراوتر بلّش فحص لحاله (آخر فحص قديم): تابعه لحد ما يخلص
      if ((d.autocheck || UP_BUSY.includes(d.state)) && !S.upTimer) upPoll(Date.now(), d.state === "downloading" || d.state === "installing");
    }
    catch (e) { $("#upOut").textContent = String(e.message || e); }
  }
  async function upPoll(t0, wasApply) {
    let d;
    try { d = await api("update_status"); } catch (_) { d = null; }   // أثناء التركيب ممكن الخادم يغيب ثواني
    if (d) renderUp(d, false);
    const busy = !d || UP_BUSY.includes(d.state) || Date.now() - t0 < 3000;
    if (busy && Date.now() - t0 < 15 * 60000) { S.upTimer = setTimeout(() => upPoll(t0, wasApply), 2000); return; }
    S.upTimer = null;
    if (wasApply && d && d.state === "done") {
      toast("تم التحديث ✓");
      $("#upOut").textContent += "\n\nالصفحة رح تتحدّث لحالها...";
      setTimeout(() => location.replace("/starbond/?v=" + encodeURIComponent(d.current || Date.now()) + location.hash), 4000);
    }
  }
  async function upRun(action) {
    if (S.upTimer) return;
    $("#btnUpCheck").disabled = $("#btnUpApply").disabled = true;
    $("#upOut").textContent = action === "update_apply" ? "عم يبلش التحديث..." : "عم يفحص...";
    try { await api(action, {}); upPoll(Date.now(), action === "update_apply"); }
    catch (e) { $("#upOut").textContent = String(e.message || e); $("#btnUpCheck").disabled = false; }
  }
  $("#btnUpSave").addEventListener("click", async () => {
    const body = { repo: $("#upRepo").value.trim(), channel: $("#upChannel").value, auto: $("#upAuto").value === "1", hour: $("#upHour").value };
    try { const d = await api("update_set", body); renderUp(d, true); toast("انحفظ ✓"); }
    catch (e) { $("#upOut").textContent = String(e.message || e); }
  });
  $("#btnUpCheck").addEventListener("click", () => upRun("update_check"));
  $("#btnUpBanner").addEventListener("click", () => $("#btnUpApply").click());
  $("#btnUpApply").addEventListener("click", async () => {
    const v = S.up && S.up.latest ? S.up.latest : "";
    if (!(await confirmBox("تحديث", `يركّب النسخة ${v} هلق؟ الخطوط ممكن تقطع ثواني، وإذا صار أي خطأ برجع للنسخة الحالية لحاله.`))) return;
    upRun("update_apply");
  });

  /* ---------------- خط لكل تطبيق ---------------- */
  const MATCH_LABEL = {
    speedtest: { addr: "اسم المزوّد بس (السرعة تضل مدموجة)", all: "الفحص كله من هالخط" },
    _: { all: "عناوين + منافذ اللعبة/التطبيق", addr: "العناوين بس" },
  };
  function appRowHtml(a, lines) {
    const opt = (v, t, sel) => `<option value="${esc(v)}"${v === sel ? " selected" : ""}>${esc(t)}</option>`;
    const lineOpts = (sel, none) => (none ? opt("", none, sel) : opt("", "— اختار خط —", sel)) +
      lines.map((l) => opt(l.iface, l.name + (l.state === "online" ? "" : " (ساقط)"), sel)).join("");
    const ml = MATCH_LABEL[a.id] || MATCH_LABEL._;
    const hasPorts = !!(a.tcp || a.udp) || a.custom;
    let pill = `<span class="pill dis">موقوف</span>`;
    if (a.enabled) pill = a.effective
      ? `<span class="pill on">على ${esc(a.effective_name || a.effective)}${a.effective !== a.line ? " (احتياطي)" : ""}</span>`
      : `<span class="pill off">الخط ساقط ← دمج عادي</span>`;
    const meta = [];
    if (a.cidrs) meta.push(`${a.cidrs} شبكة`);
    if (a.ips) meta.push(`${a.ips} عنوان من الدومينات`);
    if (a.tcp) meta.push(`TCP: ${a.tcp}`);
    if (a.udp) meta.push(`UDP: ${a.udp}`);
    const custom = a.custom ? `
      <div class="form custom">
        <label>الاسم<input data-k="name" value="${esc(a.name)}" /></label>
        <label>عناوين IP / شبكات<input data-k="cidr" dir="ltr" placeholder="1.2.3.0/24 5.6.7.8" value="${esc(a.cidr)}" /></label>
        <label class="wide">دومينات<input data-k="domains" dir="ltr" placeholder="example.com api.example.com" value="${esc(a.domains)}" /></label>
        <label>منافذ TCP<input data-k="tcp" dir="ltr" placeholder="443, 8000-8100" value="${esc(a.tcp)}" /></label>
        <label>منافذ UDP<input data-k="udp" dir="ltr" placeholder="3478, 10000-20000" value="${esc(a.udp)}" /></label>
      </div>` : "";
    return `<div class="approw${a.enabled ? " on" : ""}" data-id="${esc(a.id)}" data-custom="${a.custom ? 1 : 0}">
      <div class="approw-h"><label><input type="checkbox" data-k="enabled"${a.enabled ? " checked" : ""} />${esc(a.name)}</label>${pill}
        ${a.custom ? `<button type="button" class="btn sm ghost danger" data-del="1">حذف</button>` : ""}</div>
      ${a.desc ? `<p class="muted small">${esc(a.desc)}</p>` : ""}
      ${custom}
      <div class="form">
        <label>الخط<select data-k="line">${lineOpts(a.line)}</select></label>
        <label>احتياطي<select data-k="backup">${lineOpts(a.backup, "بدون (دمج عادي)")}</select></label>
        <label>المطابقة<select data-k="match"${hasPorts ? "" : " disabled"}>${opt("all", ml.all, a.match)}${opt("addr", ml.addr, a.match)}</select></label>
      </div>
      ${meta.length ? `<div class="meta" dir="auto">${esc(meta.join(" · "))}</div>` : ""}
      <div class="live" data-live="${esc(String(a.num || 0))}"></div>
    </div>`;
  }
  function renderApps(d) {
    S.apps = d;
    const box = $("#appList");
    if (!d.lines || !d.lines.length) { box.innerHTML = `<p class="muted">ضيف خطوط أول من صفحة الخطوط.</p>`; return; }
    box.innerHTML = (d.apps || []).map((a) => appRowHtml(a, d.lines)).join("") || `<p class="muted">ما في تطبيقات.</p>`;
  }
  function collectApps() {
    return $$("#appList .approw").map((r) => {
      const g = (k) => { const el = r.querySelector(`[data-k="${k}"]`); return el ? (el.type === "checkbox" ? el.checked : el.value.trim()) : ""; };
      const a = { id: r.dataset.id, custom: r.dataset.custom === "1", enabled: g("enabled"), line: g("line"), backup: g("backup"), match: g("match") || "all" };
      if (a.custom) { a.name = g("name"); a.cidr = g("cidr"); a.domains = g("domains"); a.tcp = g("tcp"); a.udp = g("udp"); }
      return a;
    });
  }
  async function loadApps() {
    try { renderApps(await api("apps_status")); } catch (e) { $("#appList").innerHTML = `<p class="muted">${esc(e.message || e)}</p>`; }
  }
  $("#appList").addEventListener("change", (e) => {
    const r = e.target.closest(".approw"); if (!r) return;
    if (e.target.dataset.k === "enabled") {
      r.classList.toggle("on", e.target.checked);
      const ln = r.querySelector('[data-k="line"]');
      if (e.target.checked && !ln.value && S.apps && S.apps.lines) {   // أول خط حي كاقتراح
        const l = S.apps.lines.find((x) => x.state === "online") || S.apps.lines[0];
        if (l) ln.value = l.iface;
      }
    }
    $("#appOut").textContent = "في تعديلات ما انحفظت";
  });
  $("#appList").addEventListener("click", (e) => {
    const b = e.target.closest("[data-del]"); if (!b) return;
    b.closest(".approw").remove(); $("#appOut").textContent = "في تعديلات ما انحفظت";
  });
  $("#btnAppAdd").addEventListener("click", () => {
    if (!S.apps || !S.apps.lines || !S.apps.lines.length) { toast("ضيف خطوط أول"); return; }
    const a = { id: "", custom: true, name: "", desc: "", enabled: true, line: "", backup: "", match: "all", tcp: "", udp: "", domains: "", cidr: "" };
    const l = S.apps.lines.find((x) => x.state === "online") || S.apps.lines[0]; a.line = l.iface;
    $("#appList").insertAdjacentHTML("beforeend", appRowHtml(a, S.apps.lines));
    const rows = $$("#appList .approw"); const r = rows[rows.length - 1];
    r.querySelector('[data-k="name"]').focus();
  });
  $("#btnAppSave").addEventListener("click", async () => {
    const apps = collectApps();
    for (const a of apps) if (a.enabled && !a.line) { toast("اختار خط لكل تطبيق مفعّل"); return; }
    $("#btnAppSave").disabled = true; $("#appOut").textContent = "عم يحفظ...";
    try { const d = await api("apps_save", { apps }); renderApps(d); $("#appOut").textContent = "انحفظ ✓ — الاتصالات الجديدة بتمشي على الخط المختار"; toast("انحفظ ✓"); }
    catch (e) { $("#appOut").textContent = String(e.message || e); }
    finally { $("#btnAppSave").disabled = false; }
  });

  /* ---------------- الدخول ---------------- */
  let authMode = "login";
  function showAuth(mode) {
    S.authed = false;
    mode = mode === "setup" ? "setup" : "login";
    if (!$("#auth").hidden && authMode === mode) return; // ظاهرة أصلاً: لا تمسح الخطأ ولا تسرق التركيز
    authMode = mode;
    const setup = authMode === "setup";
    $("#authTitle").textContent = setup ? "أنشئ كلمة سر للوحة" : "دخول Starbond";
    $("#authHint").textContent = setup ? "أول مرة: اختر كلمة سر (6 أحرف أو أكتر)." : "أدخل كلمة سر اللوحة.";
    $("#authPw2Wrap").classList.toggle("hidden", !setup);
    $("#authBtn").textContent = setup ? "حفظ ودخول" : "دخول";
    $("#authErr").textContent = "";
    $("#auth").hidden = false;
    setTimeout(() => $("#authPw").focus(), 50);
  }
  $("#authForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const pw = $("#authPw").value, err = $("#authErr");
    if (authMode === "setup") {
      if (pw.length < 6) { err.textContent = "لازم 6 أحرف أو أكتر"; return; }
      if (pw !== $("#authPw2").value) { err.textContent = "التأكيد ما بيطابق"; return; }
    }
    $("#authBtn").disabled = true; err.textContent = "";
    try {
      await api(authMode === "setup" ? "setup" : "login", { password: pw });
      $("#auth").hidden = true; $("#authPw").value = $("#authPw2").value = "";
      start();
    } catch (ex) { err.textContent = String(ex.message || ex); }
    finally { $("#authBtn").disabled = false; }
  });

  function start() {
    S.authed = true;
    if (!S.looping) { S.looping = true; loop(); } else poll().catch(() => { });
    luciState(null);
    upLoad(true);
    licLoad();
    if (!S.licEvery) S.licEvery = setInterval(() => { if (!document.hidden) licLoad(); }, 15 * 60000);
    if (!S.upEvery) S.upEvery = setInterval(() => { if (!S.upTimer && !document.hidden) upLoad(false); }, 30 * 60000);
    if (S.view === "tools") loadApps();
  }
  async function boot() {
    view((location.hash || "#dash").slice(1));
    try {
      const st = await api("auth_state");
      if (st.logged_in) start(); else showAuth(st.has_password ? "login" : "setup");
    } catch (_) { start(); }
  }
  window.addEventListener("resize", () => { if (S.view === "dash") { renderChart(); renderCards(); } });
  window.addEventListener("hashchange", () => view((location.hash || "#dash").slice(1)));
  boot();
})();
