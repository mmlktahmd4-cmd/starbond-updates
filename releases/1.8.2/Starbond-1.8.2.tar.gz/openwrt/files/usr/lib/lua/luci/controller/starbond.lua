module("luci.controller.starbond", package.seeall)

function index()
	-- أول عنصر في لوحة الإدارة
	entry({"admin", "starbond"}, call("action_go"), _("Starbond OS"), 0)
end

function action_go()
	luci.http.redirect("/starbond/")
end
